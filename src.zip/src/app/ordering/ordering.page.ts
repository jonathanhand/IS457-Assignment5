import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ordering',
  templateUrl: './ordering.page.html',
  styleUrls: ['./ordering.page.scss'],
})
export class OrderingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
